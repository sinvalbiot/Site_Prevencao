# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['site_prevencao']

package_data = \
{'': ['*']}

install_requires = \
['Django>=4.0.3,<5.0.0']

setup_kwargs = {
    'name': 'site-prevencao',
    'version': '0.1.0',
    'description': 'Acesso a informações do HA na Prevenção',
    'long_description': None,
    'author': 'sinval',
    'author_email': 'sinvalbiot@yahoo.com.br',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
